import 'package:flutter/material.dart';
import '../../widgets/custom_button.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Profile Setup")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(decoration: const InputDecoration(labelText: "Current Skill")),
            TextField(decoration: const InputDecoration(labelText: "Learning Goal")),
            DropdownButtonFormField(
              decoration: const InputDecoration(labelText: "Learning Style"),
              items: const [
                DropdownMenuItem(value: "Visual", child: Text("Visual")),
                DropdownMenuItem(value: "Auditory", child: Text("Auditory")),
                DropdownMenuItem(value: "Kinesthetic", child: Text("Kinesthetic")),
              ],
              onChanged: (val) {},
            ),
            const SizedBox(height: 20),
            CustomButton(
              label: "💾 Save Profile",
              icon: Icons.save,
              color: Colors.green,
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/dashboard');
              },
            ),
          ],
        ),
      ),
    );
  }
}